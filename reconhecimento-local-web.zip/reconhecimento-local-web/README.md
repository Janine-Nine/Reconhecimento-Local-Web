# Reconhecimento Local Web

Repositório com **dois projetos completos**, lado a lado:

| Pasta | O que é | Stack |
|---|---|---|
| `/src` + arquivos de configuração na raiz | **Aplicação principal** | Angular 18 + Ionic 8 (standalone) + Firebase (Firestore + Hosting) + i18n PT/EN/ES |
| `/legacy-prototype` | **Protótipo legado** | HTML5 + CSS3 + Bootstrap 5 + JavaScript puro |

O protótipo legado foi o ponto de partida visual/estrutural (5 páginas, 5
temas de cor, formulário de contato, i18n) e a aplicação principal é a
evolução dele para um app real, com componentes, roteamento, build e um
backend (Firestore) de verdade por trás do formulário de contato.

---

## 1. Aplicação principal (Angular + Ionic + Firebase)

### Stack
- Angular 18 (componentes standalone, `@if` / `@for`)
- Ionic 8 (shell `ion-app` / `ion-router-outlet`)
- `@angular/fire` 18 (Firestore modular) + Firebase Hosting
- `@ngx-translate/core` + `@ngx-translate/http-loader` para PT/EN/ES
- SCSS: `src/global.scss` é o CSS do protótipo legado portado quase 1:1

### Estrutura

```
src/
  app/
    app.component.ts        # shell: ion-app + navbar + router-outlet + footer
    app.routes.ts            # 1 rota por página legada, cada uma com seu "theme"
    core/services/
      theme.service.ts       # troca body.theme-* a cada navegação
      contact.service.ts     # grava o formulário de contato no Firestore
    shared/components/
      navbar/                # menu, troca de idioma, marca
      footer/                # rodapé com links e redes
    pages/
      home/ sobre/ projetos/ servicos/ contato/
  assets/
    i18n/{pt,en,es}.json      # todas as strings de todas as páginas
    images/logo.png
  environments/
    environment.ts            # config do Firebase (dev)
    environment.prod.ts        # config do Firebase (prod)
```

### Como rodar

```bash
npm install
npm start          # ng serve, abre em http://localhost:4200
```

### Antes de publicar

1. **Firebase**: substitua os valores `REPLACE_WITH_...` em
   `src/environments/environment.ts` e `environment.prod.ts` pelas
   credenciais reais do seu projeto Firebase (Configurações do projeto →
   Seus apps → SDK setup).
2. **Firestore**: `firestore.rules` já está restrito para só permitir
   `create` na coleção `contacts` (o formulário de contato) — sem leitura,
   atualização ou exclusão públicas. Ajuste conforme sua necessidade.
3. **.firebaserc**: o projeto Firebase está configurado como
   `reconhecimento-local-web` — troque pelo ID real do seu projeto.

### Build e deploy

```bash
npm run build                 # gera em ./www
firebase deploy --only hosting,firestore   # ou: npm run deploy
```

### O que foi portado do protótipo

- **5 páginas** (Início, Sobre, Projetos, Serviços, Contato) viraram rotas
  lazy-loaded, cada uma com o tema de cor (`theme-blue/white/green/black/navy`)
  que a página HTML original tinha fixo no `<body>`.
- **Textos com `data-i18n`** do protótipo viraram chaves nos três arquivos
  `assets/i18n/*.json`, usadas com o pipe `| translate`.
- **Formulário de contato**: agora é um `FormGroup` reativo com validação
  (nome, e-mail e mensagem obrigatórios) e grava a submissão no Firestore
  (coleção `contacts`), com estados de carregando / sucesso / erro.
- **Mapa-múndi em SVG** e a seção de presença global foram mantidos como no
  protótipo.

### Próximos passos sugeridos

- Cloud Function disparada pela escrita em `contacts` para notificar por
  e-mail.
- Testes unitários dos componentes/páginas (Karma+Jasmine já configurados).
- Build para apps nativos via Capacitor (`ionic.config.json` já referencia a
  integração, mas as pastas `android/`/`ios/` ainda não foram geradas).

---

## 2. Protótipo legado (HTML/CSS/Bootstrap/JS)

Pasta `legacy-prototype/` — um site estático, sem build, sem dependências de
node. Pode ser aberto diretamente no navegador ou hospedado em qualquer
servidor estático (Firebase Hosting, Netlify, GitHub Pages, Apache, nginx…).

### Estrutura

```
legacy-prototype/
  index.html          # redireciona para home.html
  home.html
  sobre.html
  projetos.html
  servicos.html
  contato.html
  css/
    style.css          # todo o visual: temas por página, cards, formulário, footer...
  js/
    i18n.js             # tradutor PT/EN/ES (dicionários + troca de idioma)
    main.js              # menu mobile, link ativo do menu, envio do formulário
  images/
    logo.png
```

### Como rodar

Não precisa de instalação. Duas opções:

**A) Abrir direto no navegador**
Basta abrir `legacy-prototype/home.html` (ou `index.html`, que redireciona
para `home.html`) com duplo clique.

**B) Servir localmente** (recomendado, evita restrições de `file://` em
alguns navegadores)

```bash
cd legacy-prototype
python3 -m http.server 8080
# depois acesse http://localhost:8080/home.html
```

### O que cada página faz

| Página | Tema (`body.theme-*`) | Conteúdo |
|---|---|---|
| `home.html` | `blue` | Hero, estatísticas, 3 serviços em destaque, CTA |
| `sobre.html` | `white` | Missão/visão/valores, equipe, linha do tempo |
| `projetos.html` | `green` | 6 cases de clientes, CTA |
| `servicos.html` | `black` | 6 serviços detalhados + 3 planos de preço |
| `contato.html` | `navy` | Formulário, canais de contato, redes sociais, mapa-múndi |

Cada tema muda cor de fundo, cor de destaque, cor da navbar e a paleta dos
cards — tudo via CSS custom properties (`--page-bg`, `--page-fg`,
`--page-accent`, `--nav-bg`, `--nav-fg`) sobrescritas em `body.theme-*`
dentro de `css/style.css`.

### `js/i18n.js`

- Dicionários completos PT/EN/ES (as mesmas strings usadas no app Angular).
- Aplica as traduções em qualquer elemento com `data-i18n` (texto),
  `data-i18n-placeholder` (placeholder de input) ou `data-i18n-aria-label`
  (aria-label, usado no mapa-múndi).
- Guarda o idioma escolhido em `localStorage` (`rlw-lang`), então a escolha
  persiste ao navegar entre páginas.
- Expõe `window.RLW_I18N.translate(key)` para uso por `main.js`.

### `js/main.js`

- Abre/fecha o menu no mobile (`.nav-toggle` ↔ `.nav-links.open`).
- Marca o link do menu da página atual com a classe `.active`.
- Cuida do `#contact-form`: validação simples (nome, e-mail, mensagem),
  mensagens de erro traduzidas por campo, estado de "Enviando..." no botão
  e mensagem de sucesso em `#form-success`.
- **Importante**: como é um protótipo estático (sem backend), a submissão do
  formulário é apenas simulada e guardada em `localStorage`
  (`rlw-contact-submissions`) para fins de demonstração. Quem grava de
  verdade no banco (Firestore) é a versão em `/src` (aplicação principal).

### Diferenças em relação à aplicação principal

| | Protótipo legado | Aplicação principal |
|---|---|---|
| Framework | Nenhum (HTML/CSS/JS puro) | Angular + Ionic |
| Navegação | Recarrega a página a cada link | SPA (rotas client-side) |
| i18n | `js/i18n.js` (dicionários manuais) | `@ngx-translate` + JSON |
| Formulário de contato | Simulado, salvo em `localStorage` | Grava de verdade no Firestore |
| Build/deploy | Nenhum (arquivos estáticos) | `ng build` + Firebase Hosting |
