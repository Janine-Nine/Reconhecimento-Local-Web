import { Injectable, inject } from '@angular/core';
import { Firestore, addDoc, collection, serverTimestamp } from '@angular/fire/firestore';

export interface ContactSubmission {
  name: string;
  email: string;
  phone?: string;
  business?: string;
  service?: string;
  message: string;
}

@Injectable({ providedIn: 'root' })
export class ContactService {
  private readonly firestore = inject(Firestore);

  async submit(data: ContactSubmission): Promise<void> {
    const contactsRef = collection(this.firestore, 'contacts');
    await addDoc(contactsRef, {
      ...data,
      createdAt: serverTimestamp(),
      source: 'site'
    });
  }
}
