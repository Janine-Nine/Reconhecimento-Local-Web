import { Injectable, DestroyRef, inject } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { filter, map, mergeMap } from 'rxjs/operators';

/**
 * The legacy prototype hard-coded a different `body.theme-*` class on every
 * HTML page (home=blue, sobre=white, projetos=green, servicos=black,
 * contato=navy) and let css/style.css do the rest. Since the app is now a
 * single page shell, this service reads the `theme` value declared on each
 * route and swaps the class on <body> whenever the router finishes
 * navigating, so src/global.scss keeps working unmodified.
 */
@Injectable({ providedIn: 'root' })
export class ThemeService {
  private readonly router = inject(Router);
  private readonly activatedRoute = inject(ActivatedRoute);
  private readonly destroyRef = inject(DestroyRef);

  private readonly knownThemes = ['blue', 'white', 'green', 'black', 'navy'];

  init(): void {
    this.router.events
      .pipe(
        filter((event): event is NavigationEnd => event instanceof NavigationEnd),
        map(() => {
          let route = this.activatedRoute;
          while (route.firstChild) {
            route = route.firstChild;
          }
          return route;
        }),
        mergeMap(route => route.data),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe(data => this.applyTheme((data['theme'] as string) || 'blue'));
  }

  private applyTheme(theme: string): void {
    const body = document.body;
    this.knownThemes.forEach(t => body.classList.remove(`theme-${t}`));
    body.classList.add(`theme-${theme}`);
  }
}
