import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';

import { ContactService } from '../../core/services/contact.service';

interface ServiceOption {
  value: string;
  labelKey: string;
}

type SubmitState = 'idle' | 'sending' | 'success' | 'error';

@Component({
  selector: 'app-contato',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, TranslateModule],
  templateUrl: './contato.page.html',
  styleUrl: './contato.page.scss'
})
export class ContatoPage {
  private readonly fb = inject(FormBuilder);
  private readonly contactService = inject(ContactService);

  readonly state = signal<SubmitState>('idle');

  readonly serviceOptions: ServiceOption[] = [
    { value: 'diagnostico-local', labelKey: 'servicos.s1.title' },
    { value: 'seo-perfis-locais', labelKey: 'servicos.s2.title' },
    { value: 'gestao-reputacao', labelKey: 'servicos.s3.title' },
    { value: 'criacao-site', labelKey: 'servicos.s4.title' }
  ];

  readonly form = this.fb.nonNullable.group({
    name: ['', [Validators.required, Validators.minLength(2)]],
    email: ['', [Validators.required, Validators.email]],
    phone: [''],
    business: [''],
    service: [''],
    message: ['', [Validators.required, Validators.minLength(5)]]
  });

  get f() {
    return this.form.controls;
  }

  async onSubmit(): Promise<void> {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.state.set('sending');
    const value = this.form.getRawValue();

    try {
      await this.contactService.submit(value);
      this.state.set('success');
      this.form.reset();
    } catch (err) {
      console.error('Failed to submit contact form', err);
      this.state.set('error');
    }
  }
}
