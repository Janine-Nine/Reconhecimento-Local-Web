import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';

interface StatItem {
  numberKey: string;
  labelKey: string;
}

interface ServiceItem {
  icon: string;
  titleKey: string;
  textKey: string;
}

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterLink, TranslateModule],
  templateUrl: './home.page.html',
  styleUrl: './home.page.scss'
})
export class HomePage {
  readonly stats: StatItem[] = [
    { numberKey: 'home.stat1.n', labelKey: 'home.stat1.l' },
    { numberKey: 'home.stat2.n', labelKey: 'home.stat2.l' },
    { numberKey: 'home.stat3.n', labelKey: 'home.stat3.l' }
  ];

  readonly services: ServiceItem[] = [
    { icon: '📍', titleKey: 'home.s1.title', textKey: 'home.s1.text' },
    { icon: '⭐', titleKey: 'home.s2.title', textKey: 'home.s2.text' },
    { icon: '🌐', titleKey: 'home.s3.title', textKey: 'home.s3.text' }
  ];
}
