import { Component } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';

interface ValueItem {
  icon: string;
  titleKey: string;
  textKey: string;
}

interface TeamMember {
  icon: string;
  roleKey: string;
}

interface TimelineStep {
  titleKey: string;
  textKey: string;
}

@Component({
  selector: 'app-sobre',
  standalone: true,
  imports: [TranslateModule],
  templateUrl: './sobre.page.html',
  styleUrl: './sobre.page.scss'
})
export class SobrePage {
  readonly values: ValueItem[] = [
    { icon: '🎯', titleKey: 'sobre.mission.title', textKey: 'sobre.mission.text' },
    { icon: '🔭', titleKey: 'sobre.vision.title', textKey: 'sobre.vision.text' },
    { icon: '🤝', titleKey: 'sobre.values.title', textKey: 'sobre.values.text' }
  ];

  readonly team: TeamMember[] = [
    { icon: '📊', roleKey: 'sobre.t1.role' },
    { icon: '🎨', roleKey: 'sobre.t2.role' },
    { icon: '💻', roleKey: 'sobre.t3.role' }
  ];

  readonly timeline: TimelineStep[] = [
    { titleKey: 'sobre.tl1.t', textKey: 'sobre.tl1.d' },
    { titleKey: 'sobre.tl2.t', textKey: 'sobre.tl2.d' },
    { titleKey: 'sobre.tl3.t', textKey: 'sobre.tl3.d' }
  ];
}
