import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';

interface ServiceItem {
  icon: string;
  titleKey: string;
  textKey: string;
}

interface PlanFeature {
  key: string;
}

interface PlanItem {
  nameKey: string;
  priceKey: string;
  features: PlanFeature[];
  featured: boolean;
}

@Component({
  selector: 'app-servicos',
  standalone: true,
  imports: [RouterLink, TranslateModule],
  templateUrl: './servicos.page.html',
  styleUrl: './servicos.page.scss'
})
export class ServicosPage {
  readonly services: ServiceItem[] = [
    { icon: '🔍', titleKey: 'servicos.s1.title', textKey: 'servicos.s1.text' },
    { icon: '📍', titleKey: 'servicos.s2.title', textKey: 'servicos.s2.text' },
    { icon: '⭐', titleKey: 'servicos.s3.title', textKey: 'servicos.s3.text' },
    { icon: '🌐', titleKey: 'servicos.s4.title', textKey: 'servicos.s4.text' },
    { icon: '✍️', titleKey: 'servicos.s5.title', textKey: 'servicos.s5.text' },
    { icon: '📈', titleKey: 'servicos.s6.title', textKey: 'servicos.s6.text' }
  ];

  readonly plans: PlanItem[] = [
    {
      nameKey: 'servicos.plan1.name',
      priceKey: 'servicos.plan1.price',
      featured: false,
      features: [
        { key: 'servicos.plan1.f1' },
        { key: 'servicos.plan1.f2' },
        { key: 'servicos.plan1.f3' }
      ]
    },
    {
      nameKey: 'servicos.plan2.name',
      priceKey: 'servicos.plan2.price',
      featured: true,
      features: [
        { key: 'servicos.plan2.f1' },
        { key: 'servicos.plan2.f2' },
        { key: 'servicos.plan2.f3' },
        { key: 'servicos.plan2.f4' }
      ]
    },
    {
      nameKey: 'servicos.plan3.name',
      priceKey: 'servicos.plan3.price',
      featured: false,
      features: [
        { key: 'servicos.plan3.f1' },
        { key: 'servicos.plan3.f2' },
        { key: 'servicos.plan3.f3' },
        { key: 'servicos.plan3.f4' }
      ]
    }
  ];
}
