import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';

interface ProjectItem {
  icon: string;
  titleKey: string;
  textKey: string;
}

@Component({
  selector: 'app-projetos',
  standalone: true,
  imports: [RouterLink, TranslateModule],
  templateUrl: './projetos.page.html',
  styleUrl: './projetos.page.scss'
})
export class ProjetosPage {
  readonly projects: ProjectItem[] = [
    { icon: '🥐', titleKey: 'projetos.p1.title', textKey: 'projetos.p1.text' },
    { icon: '🦷', titleKey: 'projetos.p2.title', textKey: 'projetos.p2.text' },
    { icon: '🪴', titleKey: 'projetos.p3.title', textKey: 'projetos.p3.text' },
    { icon: '🚗', titleKey: 'projetos.p4.title', textKey: 'projetos.p4.text' },
    { icon: '🧘', titleKey: 'projetos.p5.title', textKey: 'projetos.p5.text' },
    { icon: '🛒', titleKey: 'projetos.p6.title', textKey: 'projetos.p6.text' }
  ];
}
