import { Component, OnInit, inject } from '@angular/core';
import { IonApp, IonRouterOutlet } from '@ionic/angular/standalone';
import { TranslateService } from '@ngx-translate/core';

import { NavbarComponent } from './shared/components/navbar/navbar.component';
import { FooterComponent } from './shared/components/footer/footer.component';
import { ThemeService } from './core/services/theme.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [IonApp, IonRouterOutlet, NavbarComponent, FooterComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent implements OnInit {
  private readonly translate = inject(TranslateService);
  private readonly themeService = inject(ThemeService);

  private readonly supportedLangs = ['pt', 'en', 'es'];

  ngOnInit(): void {
    this.translate.addLangs(this.supportedLangs);
    this.translate.setDefaultLang('pt');

    const browserLang = (this.translate.getBrowserLang() || 'pt').toLowerCase();
    const initialLang = this.supportedLangs.includes(browserLang) ? browserLang : 'pt';
    this.translate.use(initialLang);

    this.themeService.init();
  }
}
