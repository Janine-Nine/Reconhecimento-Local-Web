import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  {
    path: 'home',
    loadComponent: () => import('./pages/home/home.page').then(m => m.HomePage),
    data: { theme: 'blue' }
  },
  {
    path: 'sobre',
    loadComponent: () => import('./pages/sobre/sobre.page').then(m => m.SobrePage),
    data: { theme: 'white' }
  },
  {
    path: 'projetos',
    loadComponent: () => import('./pages/projetos/projetos.page').then(m => m.ProjetosPage),
    data: { theme: 'green' }
  },
  {
    path: 'servicos',
    loadComponent: () => import('./pages/servicos/servicos.page').then(m => m.ServicosPage),
    data: { theme: 'black' }
  },
  {
    path: 'contato',
    loadComponent: () => import('./pages/contato/contato.page').then(m => m.ContatoPage),
    data: { theme: 'navy' }
  },
  { path: '**', redirectTo: 'home' }
];
