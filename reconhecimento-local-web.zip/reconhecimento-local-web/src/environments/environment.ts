export const environment = {
  production: false,
  firebase: {
    apiKey: 'REPLACE_WITH_YOUR_API_KEY',
    authDomain: 'reconhecimento-local-web.firebaseapp.com',
    projectId: 'reconhecimento-local-web',
    storageBucket: 'reconhecimento-local-web.appspot.com',
    messagingSenderId: 'REPLACE_WITH_SENDER_ID',
    appId: 'REPLACE_WITH_APP_ID'
  }
};
